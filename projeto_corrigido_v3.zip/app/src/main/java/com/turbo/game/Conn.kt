package com.turbo.game

import android.content.Context
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Security
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.conscrypt.Conscrypt
import rikka.shizuku.Shizuku

/** Conexão via Shizuku. O app Shizuku precisa estar instalado e ligado, e o Turbo Game autorizado nele. */
object ShizukuSh {
    const val PKG = "moe.shizuku.privileged.api"

    /** 0 = não instalado, 1 = instalado mas desligado, 2 = ligado sem permissão, 3 = autorizado */
    fun state(c: Context): Int {
        if (granted()) return 3
        if (running()) return 2
        val inst = try {
            c.packageManager.getPackageInfo(PKG, 0)
            true
        } catch (e: Exception) {
            false
        }
        return if (inst) 1 else 0
    }

    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun request() {
        try {
            Shizuku.requestPermission(88)
        } catch (e: Throwable) {
        }
    }

    /** Shizuku.newProcess é privado nas versões 13.x, por isso a reflexão (é o jeito usado pelos apps que o integram). */
    fun run(cmd: String): String? = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        val r = e.cause ?: e
        Sh.lastErr = "Shizuku: " + (r.message?.takeIf { it.isNotBlank() } ?: r.javaClass.simpleName)
        null
    }
}

/** Chaves do ADB deste app (geradas uma vez e guardadas na pasta privada). */
class AdbMgr(private val c: Context) : AbsAdbConnectionManager() {
    private val key: PrivateKey
    private val cert: Certificate

    init {
        try {
            if (Security.getProvider("Conscrypt") == null) Security.insertProviderAt(Conscrypt.newProvider(), 1)
        } catch (e: Throwable) {
        }
        setApi(Build.VERSION.SDK_INT)
        val kf = File(c.filesDir, "adb_key.pk8")
        val cf = File(c.filesDir, "adb_cert.der")
        val kp = load(kf, cf) ?: create(kf, cf)
        key = kp.first
        cert = kp.second
    }

    private fun load(kf: File, cf: File): Pair<PrivateKey, Certificate>? = try {
        if (!kf.exists() || !cf.exists()) {
            null
        } else {
            val k = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            val ce = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            Pair(k, ce)
        }
    } catch (e: Exception) {
        null
    }

    private fun create(kf: File, cf: File): Pair<PrivateKey, Certificate> {
        val g = KeyPairGenerator.getInstance("RSA")
        g.initialize(2048)
        val kp = g.generateKeyPair()
        val now = System.currentTimeMillis()
        val name = X500Name("CN=TurboGame")
        val holder = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now), Date(now), Date(now + TimeUnit.DAYS.toMillis(3650)), name, kp.public
        ).build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
        val ce: Certificate = JcaX509CertificateConverter().getCertificate(holder)
        try {
            kf.writeBytes(kp.private.encoded)
            cf.writeBytes(ce.encoded)
        } catch (e: Exception) {
        }
        return Pair(kp.private, ce)
    }

    override fun getPrivateKey(): PrivateKey = key

    override fun getCertificate(): Certificate = cert

    override fun getDeviceName(): String = "TurboGame"
}

/**
 * Conexão via Depuração por Wi-Fi (Android 11+): o app se conecta no próprio celular (127.0.0.1).
 * 1) Parear uma vez com o código; 2) Conectar. A porta de conexão muda sempre que o Wi-Fi reinicia,
 * por isso o app a procura sozinho (mDNS) quando a última porta não funciona mais.
 */
object WifiAdb {
    private const val HOST = "127.0.0.1"

    @Volatile private var mgr: AdbMgr? = null

    private fun sp(c: Context) = c.getSharedPreferences("tgwifi", Context.MODE_PRIVATE)

    @Synchronized
    private fun m(c: Context): AdbMgr {
        var x = mgr
        if (x == null) {
            x = AdbMgr(c.applicationContext)
            mgr = x
        }
        return x
    }

    /** Descarta a conexão (a próxima chamada cria uma nova, com as mesmas chaves). */
    @Synchronized
    private fun drop() {
        try {
            mgr?.close()
        } catch (e: Throwable) {
        }
        mgr = null
    }

    private fun err(e: Throwable): String = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName

    fun connected(): Boolean = try {
        mgr?.isConnected == true
    } catch (e: Throwable) {
        false
    }

    /** 0 = não pareado, 1 = pareado, 2 = conectado */
    fun state(c: Context): Int = when {
        connected() -> 2
        sp(c).getBoolean("paired", false) -> 1
        else -> 0
    }

    private fun wifiDbgOn(c: Context): Boolean = try {
        Settings.Global.getInt(c.contentResolver, "adb_wifi_enabled", 0) == 1
    } catch (e: Throwable) {
        false
    }

    private fun isLocal(a: java.net.InetAddress?): Boolean {
        if (a == null) return false
        if (a.isLoopbackAddress) return true
        return try {
            val en = java.net.NetworkInterface.getNetworkInterfaces()
            var r = false
            while (en != null && en.hasMoreElements() && !r) {
                val ias = en.nextElement().inetAddresses
                while (ias.hasMoreElements()) {
                    if (ias.nextElement() == a) {
                        r = true
                        break
                    }
                }
            }
            r
        } catch (e: Throwable) {
            false
        }
    }

    /** Procura (mDNS) a porta de conexão da Depuração sem fio DESTE celular. */
    @Suppress("DEPRECATION")
    private fun discover(c: Context, timeoutMs: Long): List<Int> {
        if (Build.VERSION.SDK_INT < 30) return emptyList()
        val nsd = c.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return emptyList()
        val found = java.util.concurrent.ConcurrentLinkedQueue<NsdServiceInfo>()
        val ports = java.util.concurrent.CopyOnWriteArrayList<Int>()
        val dl = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(t: String?, e: Int) {}
            override fun onStopDiscoveryFailed(t: String?, e: Int) {}
            override fun onDiscoveryStarted(t: String?) {}
            override fun onDiscoveryStopped(t: String?) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                found.add(i)
            }
            override fun onServiceLost(i: NsdServiceInfo) {}
        }
        try {
            nsd.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, dl)
            val end = SystemClock.elapsedRealtime() + timeoutMs
            while (SystemClock.elapsedRealtime() < end && ports.isEmpty()) {
                val i = found.poll()
                if (i == null) {
                    Thread.sleep(100)
                    continue
                }
                val latch = CountDownLatch(1)
                nsd.resolveService(i, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo?, e: Int) {
                        latch.countDown()
                    }
                    override fun onServiceResolved(s: NsdServiceInfo) {
                        if (isLocal(s.host)) ports.add(s.port)
                        latch.countDown()
                    }
                })
                latch.await(2, TimeUnit.SECONDS)
            }
        } catch (e: Throwable) {
        } finally {
            try {
                nsd.stopServiceDiscovery(dl)
            } catch (e: Throwable) {
            }
        }
        return ports.toList()
    }

    fun pair(c: Context, port: Int, code: String): Pair<Boolean, String> = try {
        if (Build.VERSION.SDK_INT < 30) {
            Pair(false, "O pareamento por código só existe no Android 11 ou mais novo")
        } else if (m(c).pair(HOST, port, code)) {
            sp(c).edit().putBoolean("paired", true).apply()
            Pair(true, "Pareado! Agora toque em Conectar")
        } else {
            Pair(false, "Não pareou: confira a porta e o código")
        }
    } catch (e: Throwable) {
        Pair(false, err(e))
    }

    private fun tryConnect(c: Context, p: Int): Pair<Boolean, String> = try {
        if (m(c).connect(HOST, p)) {
            sp(c).edit().putInt("port", p).putBoolean("paired", true).apply()
            Pair(true, "Conectado")
        } else {
            Pair(false, "Não conectou: confira a porta")
        }
    } catch (e: Throwable) {
        Pair(false, err(e))
    }

    /** port = null: usa a última porta e, se ela não funcionar mais, procura a atual sozinho. */
    fun connect(c: Context, port: Int?): Pair<Boolean, String> {
        val explicit = port != null && port > 0
        val first = if (port != null && port > 0) port else sp(c).getInt("port", 0)
        var last = ""
        if (first > 0) {
            val r = tryConnect(c, first)
            if (r.first) return r
            last = r.second
            drop()
        }
        if (explicit) return Pair(false, last)
        if (!wifiDbgOn(c)) return Pair(false, "Ligue a Depuração sem fio nas Opções do desenvolvedor")
        for (p in discover(c, 4000)) {
            if (p == first) continue
            val r = tryConnect(c, p)
            if (r.first) return r
            last = r.second
            drop()
        }
        return Pair(false, if (last.isNotEmpty()) last else "Não achei a porta da Depuração sem fio: digite a porta de conexão")
    }

    fun ready(c: Context): Boolean {
        if (connected()) return true
        if (!sp(c).getBoolean("paired", false) && sp(c).getInt("port", 0) <= 0) return false
        val r = connect(c, null)
        if (!r.first) Sh.lastErr = "Wi‑Fi: " + r.second
        return r.first
    }

    fun run(c: Context, cmd: String): String? {
        for (attempt in 0..1) {
            try {
                if (!ready(c)) return null
                val st = mgr!!.openStream("shell:$cmd")
                try {
                    return st.openInputStream().bufferedReader().readText()
                } finally {
                    try {
                        st.close()
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Throwable) {
                Sh.lastErr = "Wi‑Fi: " + err(e)
                drop()
            }
        }
        return null
    }
}
