package com.turbo.game

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import org.json.JSONObject

/** Lê boolean de um JSON aceitando true/false, 1/0 e "true". (optBoolean ignora números!) */
fun JSONObject.flag(k: String, d: Boolean = false): Boolean = when (val v = opt(k)) {
    is Boolean -> v
    is Number -> v.toInt() != 0
    is String -> v == "true" || v == "1"
    else -> d
}

/**
 * Acesso avançado ao sistema. Funciona por 3 caminhos: root, Shizuku ou Depuração por Wi-Fi.
 * `peek()`/`hasRoot()` continuam com o mesmo nome: agora significam "tem acesso avançado por algum caminho".
 */
object Sh {
    const val NONE = 0
    const val ROOT = 1
    const val SHIZUKU = 2
    const val WIFI = 3

    @Volatile private var ctx: Context? = null
    @Volatile private var checked = false

    /** Último erro de conexão/comando, para mostrar na tela. */
    @Volatile var lastErr = ""

    /** Caminho em uso agora (NONE/ROOT/SHIZUKU/WIFI). */
    @Volatile var mode = NONE
        private set

    fun init(c: Context) {
        if (ctx == null) ctx = c.applicationContext
    }

    private fun sp() = ctx?.getSharedPreferences("tgsh", Context.MODE_PRIVATE)

    /** 0 = automático (root, depois Shizuku, depois Wi-Fi); 1/2/3 = fixa um caminho. */
    fun pref(): Int = sp()?.getInt("mode", 0) ?: 0

    fun setPref(m: Int) {
        sp()?.edit()?.putInt("mode", m)?.apply()
    }

    private fun runRoot(cmd: String): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        lastErr = "Root: " + (e.message ?: e.javaClass.simpleName)
        null
    }

    /** Roda o comando pelo caminho em uso. null = sem conexão ou falhou. */
    fun run(cmd: String): String? = when (mode) {
        ROOT -> runRoot(cmd)
        SHIZUKU -> ShizukuSh.run(cmd)
        WIFI -> ctx?.let { WifiAdb.run(it, cmd) }
        else -> null
    }

    private fun test(m: Int): Boolean = try {
        when (m) {
            ROOT -> runRoot("id")?.contains("uid=0") == true
            SHIZUKU -> ShizukuSh.granted() && ShizukuSh.run("id")?.contains("uid=") == true
            WIFI -> ctx?.let { WifiAdb.ready(it) } == true
            else -> false
        }
    } catch (e: Throwable) {
        false
    }

    /** Verifica tudo de novo (pode abrir o pedido do Magisk). Chame fora da thread principal. */
    @Synchronized
    fun detect(): Int {
        val p = pref()
        val order = if (p in 1..3) listOf(p) else listOf(ROOT, SHIZUKU, WIFI)
        var found = NONE
        for (m in order) {
            if (test(m)) {
                found = m
                break
            }
        }
        mode = found
        checked = true
        return found
    }

    /** Igual ao detect(), mas sem tentar o root (não incomoda o Magisk). Usado ao voltar para o app. */
    @Synchronized
    fun soft(): Int {
        if (mode == ROOT) return mode
        val p = pref()
        if (p == ROOT) return mode
        val order = if (p in 1..3) listOf(p) else listOf(SHIZUKU, WIFI)
        for (m in order) {
            if (test(m)) {
                mode = m
                checked = true
                return m
            }
        }
        mode = NONE
        checked = true
        return NONE
    }

    /** null = ainda não verificado */
    fun peek(): Boolean? = if (checked) mode != NONE else null

    fun hasRoot(): Boolean {
        if (!checked) detect()
        return mode != NONE
    }
}

/** Opções salvas no nativo: o app e o ícone flutuante usam as mesmas. */
object Opts {
    private fun p(c: Context) = c.getSharedPreferences("tg", Context.MODE_PRIVATE)

    fun get(c: Context): JSONObject = try {
        JSONObject(p(c).getString("o", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun set(c: Context, o: JSONObject) {
        p(c).edit().putString("o", o.toString()).apply()
    }

    fun put(c: Context, k: String, v: Any) {
        val o = get(c)
        o.put(k, v)
        set(c, o)
    }
}

/** Ajustes do sistema: funcionam com root OU com a permissão WRITE_SECURE_SETTINGS (concedida 1 vez via adb). */
object Priv {
    fun secure(c: Context): Boolean =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun canSet(c: Context): Boolean = secure(c) || Sh.hasRoot()

    fun putGlobal(c: Context, k: String, v: String): Boolean {
        if (secure(c)) {
            try {
                return Settings.Global.putString(c.contentResolver, k, v)
            } catch (e: Exception) {
            }
        }
        if (Sh.hasRoot()) {
            val out = Sh.run("settings put global $k $v")
            return out != null && !out.contains("Exception", true)
        }
        return false
    }

    fun animOn(c: Context): Boolean {
        val v = try {
            Settings.Global.getString(c.contentResolver, "animator_duration_scale")
        } catch (e: Exception) {
            null
        }
        return (v?.toFloatOrNull() ?: 1f) <= 0.5f
    }

    fun setAnim(c: Context, on: Boolean): Boolean {
        val v = if (on) "0.5" else "1.0"
        val a = putGlobal(c, "window_animation_scale", v)
        val b = putGlobal(c, "transition_animation_scale", v)
        val d = putGlobal(c, "animator_duration_scale", v)
        return a && b && d
    }

    /** A economia de bateria limita a CPU/GPU e derruba o FPS. */
    fun batteryOff(c: Context) {
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isPowerSaveMode) putGlobal(c, "low_power", "0")
    }
}

object Sys {
    private fun freeBytes(): Long = StatFs(Environment.getDataDirectory().absolutePath).availableBytes

    fun stats(c: Context): JSONObject {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val b: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val t = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        var th = 0
        if (Build.VERSION.SDK_INT >= 29) {
            th = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
        }
        val sf = StatFs(Environment.getDataDirectory().absolutePath)
        return JSONObject()
            .put("ram", (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt())
            .put("free", (mi.availMem / 1048576).toInt())
            .put("temp", t)
            .put("bat", 100 * lvl / sc)
            .put("th", th)
            .put("sfree", sf.availableBytes / 1048576)
            .put("stot", sf.totalBytes / 1048576)
    }

    /** Fecha apps em segundo plano. `except` = app que não deve ser tocado (o jogo). */
    fun cleanRam(c: Context, except: String? = null): JSONObject {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val before = mi.availMem
        for (a in c.packageManager.getInstalledApplications(0)) {
            if (a.packageName != c.packageName && a.packageName != except) am.killBackgroundProcesses(a.packageName)
        }
        if (Sh.peek() == true) Sh.run("am kill-all")
        Thread.sleep(1200)
        am.getMemoryInfo(mi)
        return JSONObject()
            .put("mb", maxOf(0L, (mi.availMem - before) / 1048576))
            .put("free", mi.availMem / 1048576)
    }

    /**
     * Limpa o cache de TODOS os apps sem root: pede ao Android o máximo de espaço possível
     * (StorageManager.allocateBytes) e ele apaga os caches para atender. Mede o espaço real liberado.
     */
    fun cleanSys(c: Context): JSONObject {
        val before = freeBytes()
        try {
            val sm = c.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val uuid = sm.getUuidForPath(c.filesDir)
            val ask = sm.getAllocatableBytes(uuid) - 64L * 1048576
            if (ask > before) sm.allocateBytes(uuid, ask)
        } catch (e: Exception) {
        }
        if (Sh.peek() == true) Sh.run("pm trim-caches 999999999999")
        Thread.sleep(700)
        return JSONObject().put("mb", maxOf(0L, (freeBytes() - before) / 1048576))
    }

    fun cleanOwn(c: Context): Long {
        var n = 0L
        for (d in listOf(c.cacheDir, c.externalCacheDir)) {
            if (d != null) {
                for (f in d.walkTopDown()) if (f.isFile) n += f.length()
                d.listFiles()?.forEach { it.deleteRecursively() }
            }
        }
        return n / 1048576
    }
}

/**
 * Gráfico leve: reduz a resolução da tela (e a densidade junto, para o layout não mudar) enquanto o jogo roda.
 * A GPU desenha menos pixels, então o FPS sobe. Não troca as texturas do jogo. Precisa de root, Shizuku ou Wi-Fi.
 * A resolução original é devolvida quando o ícone ⚡ fecha (ou ao abrir o Turbo Game de novo).
 */
object Gfx {
    const val NORMAL = 0
    const val MINE = 1
    const val POTATO = 2
    const val CUSTOM = 3

    private fun p(c: Context) = c.getSharedPreferences("tggfx", Context.MODE_PRIVATE)

    fun current(c: Context): Int = p(c).getInt("mode", 0)

    private fun scale(m: Int): Float = when (m) {
        MINE -> 0.7f
        POTATO -> 0.5f
        else -> 1f
    }

    private fun even(v: Float): Int = maxOf(2, (Math.round(v) / 2) * 2)

    fun restore(c: Context): Pair<Boolean, String> {
        if (Sh.peek() != true) return Pair(false, "Precisa de root, Shizuku ou Wi‑Fi")
        val out = Sh.run("wm size reset; wm density reset")
        return if (out == null) {
            Pair(false, "Não consegui restaurar: " + Sh.lastErr)
        } else {
            p(c).edit().putInt("mode", NORMAL).apply()
            Pair(true, "Gráfico normal")
        }
    }

    /** "Original 1080×2400 · agora 756×1680" (ou null sem conexão). */
    fun describe(): String? {
        val o = Sh.run("wm size") ?: return null
        val p = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(o) ?: return null
        val ov = Regex("Override size:\\s*(\\d+)x(\\d+)").find(o)
        val base = "Original ${p.groupValues[1]}×${p.groupValues[2]}"
        return if (ov != null) "$base · agora ${ov.groupValues[1]}×${ov.groupValues[2]}" else "$base · agora igual"
    }

    /**
     * Resolução personalizada: o usuário digita largura e altura em pixels (em qualquer ordem).
     * A densidade é reduzida na mesma proporção para o layout não mudar de tamanho.
     */
    fun custom(c: Context, wIn: Int, hIn: Int): Pair<Boolean, String> {
        if (Sh.peek() != true) return Pair(false, "Precisa de root, Shizuku ou Wi‑Fi")
        val sizeOut = Sh.run("wm size") ?: return Pair(false, "Sem resposta: " + Sh.lastErr)
        val densOut = Sh.run("wm density") ?: return Pair(false, "Sem resposta: " + Sh.lastErr)
        val sm = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(sizeOut)
            ?: return Pair(false, "Não consegui ler a resolução da tela")
        val dm = Regex("Physical density:\\s*(\\d+)").find(densOut)
            ?: return Pair(false, "Não consegui ler a densidade da tela")
        val pw = sm.groupValues[1].toInt()
        val ph = sm.groupValues[2].toInt()
        val d = dm.groupValues[1].toInt()
        // o Android sempre usa a ordem da tela em pé: a menor medida é a largura
        var w = minOf(wIn, hIn)
        var h = maxOf(wIn, hIn)
        if (pw > ph) {
            w = maxOf(wIn, hIn)
            h = minOf(wIn, hIn)
        }
        if (w < 320 || h < 320) return Pair(false, "Muito pequena: o mínimo é 320 px")
        if (w > pw || h > ph) return Pair(false, "Maior que a tela (${pw}x$ph)")
        w = even(w.toFloat())
        h = even(h.toFloat())
        if (w == pw && h == ph) return restore(c)
        val d2 = maxOf(120, Math.round(d * w.toFloat() / pw))
        Sh.run("wm size ${w}x$h; wm density $d2")
        val check = Sh.run("wm size") ?: ""
        return if (check.contains("Override size: ${w}x$h")) {
            p(c).edit().putInt("mode", CUSTOM).apply()
            Pair(true, "Resolução ${w}x$h ativa")
        } else {
            Pair(false, "O aparelho não aceitou essa resolução: " + check.trim().replace("\n", " ").take(90))
        }
    }

    fun apply(c: Context, m: Int): Pair<Boolean, String> {
        if (m == NORMAL) return restore(c)
        if (Sh.peek() != true) return Pair(false, "Precisa de root, Shizuku ou Wi‑Fi")
        val sizeOut = Sh.run("wm size") ?: return Pair(false, "Sem resposta: " + Sh.lastErr)
        val densOut = Sh.run("wm density") ?: return Pair(false, "Sem resposta: " + Sh.lastErr)
        val sm = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(sizeOut)
            ?: return Pair(false, "Não consegui ler a resolução da tela")
        val dm = Regex("Physical density:\\s*(\\d+)").find(densOut)
            ?: return Pair(false, "Não consegui ler a densidade da tela")
        val w = sm.groupValues[1].toInt()
        val h = sm.groupValues[2].toInt()
        val d = dm.groupValues[1].toInt()
        val k = scale(m)
        val w2 = even(w * k)
        val h2 = even(h * k)
        val d2 = maxOf(120, Math.round(d * k))
        Sh.run("wm size ${w2}x$h2; wm density $d2")
        val check = Sh.run("wm size") ?: ""
        return if (check.contains("Override size: ${w2}x$h2")) {
            p(c).edit().putInt("mode", m).apply()
            Pair(true, if (m == MINE) "Gráfico Minecraft ativo (${w2}x$h2)" else "Gráfico batata ativo (${w2}x$h2)")
        } else {
            Pair(false, "O aparelho não aceitou mudar a resolução: " + check.trim().replace("\n", " ").take(90))
        }
    }
}
